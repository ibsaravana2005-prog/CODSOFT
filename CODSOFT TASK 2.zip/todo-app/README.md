# To-Do List Application (Task 2)

Built with HTML, CSS and JavaScript. No installation needed.

## Files
- index.html  page structure
- style.css   design (responsive, light + dark mode)
- script.js   logic, Local Storage, sample data
- data/sample-tasks.json / .csv (12 tasks) and data/large-tasks.json / .csv (30 tasks)

## Run
1. Extract the zip.
2. Double-click index.html (Chrome / Edge), or use Live Server in VS Code.
3. Click "Load sample tasks".

## Expected output
Load sample tasks (12): Total 12, Completed 5, Pending 7, Overdue 1, progress 42%.
Load large dataset (30): Total 30, Completed 11, Pending 19, Overdue 1, progress 37%.
Large dataset filters: Study 8, Work 8, Personal 6, Health 4, Shopping 4. Priority High 7.
Search "github" -> 1 task. Search "budget" (notes) -> 1 task.

## Requirements covered
Responsive UI, add with validation (empty, too short, duplicate), edit, delete,
complete/pending toggle, Local Storage, completed + pending counts, search and filters.
Bonus: categories, priority levels, due dates, dark mode.
Extras: notes, sorting, progress by category, 30-task dataset.

/* Portfolio - script.js */
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];

/* ---------- Data ---------- */
const SKILLS = [
  ["HTML","web"],["CSS","web"],["JavaScript","web"],["Responsive Web Design","web"],["Front-End Development","web"],["Web Application Development","web"],
  ["Power BI","data"],["Power Query","data"],["DAX","data"],["Data Analysis","data"],["Data Cleaning","data"],["Data Visualization","data"],["Dashboard Development","data"],
  ["SQL","tools"],["MS Excel","tools"],["Git","tools"],["GitHub","tools"],["Visual Studio Code","tools"],["Database Management","tools"],
  ["Analytical Thinking","soft"],["Problem Solving","soft"],["Effective Communication","soft"],["Team Collaboration","soft"],["Adaptability","soft"]
];
const GH = "https://github.com/ibsaravana2005-prog";   /* change to each repo link after you upload */
const PROJECTS = [
  {t:"Expense Tracker",c:"web",img:"images/expense.jpg",d:"Track income and expenses with category filters, summary cards, edit/delete and Local Storage.",tags:["HTML","CSS","JavaScript","Local Storage"],demo:"projects/expense-tracker/index.html",code:GH},
  {t:"To-Do List App",c:"web",img:"images/todo.jpg",d:"Task manager with validation, priorities, due dates, search, filters, progress tracking and dark mode.",tags:["HTML","CSS","JavaScript","Dark mode"],demo:"projects/todo-app/index.html",code:GH},
  {t:"Sales Performance & Analytics Dashboard",c:"data",img:"images/powerbi.svg",d:"Interactive Power BI dashboard with KPI cards, slicers and DAX measures to analyse sales trends and product performance.",tags:["Power BI","Power Query","DAX","Excel"],code:GH}
];
const ROLES = ["Front-End Developer","Web Developer","Data Analytics Enthusiast","Problem Solver"];

/* ---------- Skills + projects with filter tabs ---------- */
function drawSkills(f="all"){
  $("#skillChips").innerHTML = SKILLS.filter(s => f==="all" || s[1]===f).map(s => `<span class="chip">${s[0]}</span>`).join("");
}
function drawProjects(f="all"){
  $("#cards").innerHTML = PROJECTS.filter(p => f==="all" || p.c===f).map(p => `
    <article class="card">
      <div class="img"><img src="${p.img}" alt="${p.t} preview" loading="lazy"></div>
      <div class="body">
        <h3>${p.t}</h3><p>${p.d}</p>
        <div class="tags">${p.tags.map(t => `<span>${t}</span>`).join("")}</div>
        <div class="links2">${p.demo ? `<a href="${p.demo}" target="_blank" rel="noopener">Live demo →</a>` : ""}<a href="${p.code}" target="_blank" rel="noopener">GitHub</a></div>
      </div>
    </article>`).join("");
}
function tabs(id, fn){
  $(id).addEventListener("click", e => {
    const b = e.target.closest(".tab"); if (!b) return;
    $$(id + " .tab").forEach(x => x.classList.toggle("on", x === b)); fn(b.dataset.f);
  });
}
tabs("#skillTabs", drawSkills); tabs("#projTabs", drawProjects);
drawSkills(); drawProjects();

/* ---------- Typing effect ---------- */
(function(){
  const el = $("#typed"); let r = 0, i = 0, del = false;
  if (matchMedia("(prefers-reduced-motion: reduce)").matches){ el.textContent = ROLES[0]; return; }
  (function tick(){
    const w = ROLES[r];
    el.textContent = w.slice(0, del ? --i : ++i);
    let wait = del ? 40 : 90;
    if (!del && i === w.length){ del = true; wait = 1400; }
    else if (del && i === 0){ del = false; r = (r + 1) % ROLES.length; wait = 300; }
    setTimeout(tick, wait);
  })();
})();

/* ---------- Mobile menu, theme, active link, back-to-top ---------- */
$("#menu").addEventListener("click", () => {
  const o = $("#links").classList.toggle("open"); $("#menu").setAttribute("aria-expanded", o);
});
$$("#links a").forEach(a => a.addEventListener("click", () => { $("#links").classList.remove("open"); $("#menu").setAttribute("aria-expanded","false"); }));
function setTheme(t){
  document.documentElement.setAttribute("data-theme", t);
  try { localStorage.setItem("portfolio-theme", t); } catch {}
  $("#theme").textContent = t === "dark" ? "☀" : "🌙";
}
$("#theme").addEventListener("click", () => setTheme(document.documentElement.dataset.theme === "dark" ? "light" : "dark"));
let saved = "dark"; try { saved = localStorage.getItem("portfolio-theme") || "dark"; } catch {}
setTheme(saved);

const secs = $$("main section[id]");
function onScroll(){
  const y = scrollY + 120; let cur = secs[0].id;
  secs.forEach(s => { if (s.offsetTop <= y) cur = s.id; });
  $$("#links a").forEach(a => a.classList.toggle("on", a.getAttribute("href") === "#" + cur));
  $("#toTop").classList.toggle("show", scrollY > 500);
}
addEventListener("scroll", onScroll, {passive:true}); onScroll();

/* ---------- Scroll reveal ---------- */
if ("IntersectionObserver" in window){
  const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting){ e.target.classList.add("in-view"); io.unobserve(e.target); } }), {threshold:.12});
  $$(".reveal").forEach(el => io.observe(el));
} else $$(".reveal").forEach(el => el.classList.add("in-view"));

/* ---------- Contact form validation ---------- */
const rules = {
  name:    v => !v ? "Please enter your name." : v.length < 2 ? "Name must be at least 2 characters." : !/^[A-Za-z .'-]+$/.test(v) ? "Name can only contain letters and spaces." : "",
  email:   v => !v ? "Please enter your email." : !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) ? "Enter a valid email address." : "",
  subject: v => !v ? "Please enter a subject." : v.length < 3 ? "Subject must be at least 3 characters." : "",
  message: v => !v ? "Please write a message." : v.length < 10 ? "Message must be at least 10 characters." : ""
};
function check(id){
  const el = $("#" + id), msg = rules[id](el.value.trim());
  $("#e-" + id).textContent = msg; el.classList.toggle("bad", !!msg); return !msg;
}
Object.keys(rules).forEach(id => {
  $("#" + id).addEventListener("blur", () => check(id));
  $("#" + id).addEventListener("input", () => { if ($("#e-" + id).textContent) check(id); });
});
$("#message").addEventListener("input", e => $("#count").textContent = e.target.value.length + "/500");
$("#form").addEventListener("submit", e => {
  e.preventDefault(); $("#ok").textContent = "";
  const valid = Object.keys(rules).map(check).every(Boolean);
  if (!valid){ const bad = $(".bad"); if (bad) bad.focus(); return; }
  const n = $("#name").value.trim(), s = $("#subject").value.trim(), m = $("#message").value.trim(), em = $("#email").value.trim();
  $("#ok").textContent = `Thanks, ${n}! Your email app is opening so you can send the message.`;
  location.href = `mailto:ibsaravana2005@gmail.com?subject=${encodeURIComponent(s)}&body=${encodeURIComponent(m + "\n\nFrom: " + n + " (" + em + ")")}`;
  e.target.reset(); $("#count").textContent = "0/500";
});

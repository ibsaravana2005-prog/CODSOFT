/* To-Do List - script.js
   Tasks are saved in Local Storage, so they stay after refresh. */
const KEY = "todo-app-tasks";
const THEME_KEY = "todo-app-theme";
const CATEGORIES = ["Study", "Work", "Personal", "Health", "Shopping"];

/* Sample dataset (same data as data/sample-tasks.json). dueInDays is counted from today. */
const SAMPLE = [
  {
    "title": "Complete HTML assignment",
    "category": "Study",
    "priority": "High",
    "done": true,
    "dueInDays": -2,
    "notes": ""
  },
  {
    "title": "Revise JavaScript arrays",
    "category": "Study",
    "priority": "High",
    "done": false,
    "dueInDays": 1,
    "notes": ""
  },
  {
    "title": "Upload project to GitHub",
    "category": "Work",
    "priority": "High",
    "done": false,
    "dueInDays": 0,
    "notes": ""
  },
  {
    "title": "Update LinkedIn profile",
    "category": "Work",
    "priority": "Medium",
    "done": true,
    "dueInDays": -1,
    "notes": ""
  },
  {
    "title": "Record project demo video",
    "category": "Work",
    "priority": "High",
    "done": false,
    "dueInDays": 2,
    "notes": ""
  },
  {
    "title": "Buy notebooks and pens",
    "category": "Shopping",
    "priority": "Low",
    "done": false,
    "dueInDays": 3,
    "notes": ""
  },
  {
    "title": "Morning walk for 30 minutes",
    "category": "Health",
    "priority": "Medium",
    "done": true,
    "dueInDays": 0,
    "notes": ""
  },
  {
    "title": "Pay mobile recharge",
    "category": "Personal",
    "priority": "Medium",
    "done": false,
    "dueInDays": -1,
    "notes": ""
  },
  {
    "title": "Call grandmother",
    "category": "Personal",
    "priority": "Low",
    "done": true,
    "dueInDays": -3,
    "notes": ""
  },
  {
    "title": "Practice SQL queries",
    "category": "Study",
    "priority": "Medium",
    "done": false,
    "dueInDays": 4,
    "notes": ""
  },
  {
    "title": "Clean study table",
    "category": "Personal",
    "priority": "Low",
    "done": false,
    "dueInDays": 5,
    "notes": ""
  },
  {
    "title": "Prepare resume for internship",
    "category": "Work",
    "priority": "High",
    "done": true,
    "dueInDays": -4,
    "notes": ""
  }
];
const LARGE = [
  {
    "title": "Complete HTML assignment",
    "category": "Study",
    "priority": "High",
    "done": true,
    "dueInDays": -2,
    "notes": "Semantic tags and forms"
  },
  {
    "title": "Revise JavaScript arrays",
    "category": "Study",
    "priority": "High",
    "done": false,
    "dueInDays": 1,
    "notes": "map, filter and reduce"
  },
  {
    "title": "Practice SQL queries",
    "category": "Study",
    "priority": "Medium",
    "done": false,
    "dueInDays": 4,
    "notes": "JOINs and GROUP BY"
  },
  {
    "title": "Read CSS Grid tutorial",
    "category": "Study",
    "priority": "Medium",
    "done": true,
    "dueInDays": -5,
    "notes": ""
  },
  {
    "title": "Solve 10 coding problems",
    "category": "Study",
    "priority": "Medium",
    "done": false,
    "dueInDays": 2,
    "notes": ""
  },
  {
    "title": "Prepare for internal exam",
    "category": "Study",
    "priority": "High",
    "done": false,
    "dueInDays": 6,
    "notes": "Units 3 and 4"
  },
  {
    "title": "Finish Excel pivot table practice",
    "category": "Study",
    "priority": "Medium",
    "done": true,
    "dueInDays": -3,
    "notes": ""
  },
  {
    "title": "Watch React intro video",
    "category": "Study",
    "priority": "Low",
    "done": false,
    "dueInDays": 7,
    "notes": ""
  },
  {
    "title": "Upload project to GitHub",
    "category": "Work",
    "priority": "High",
    "done": false,
    "dueInDays": 0,
    "notes": "Repo name: CODSOFT_TASKSNO"
  },
  {
    "title": "Update LinkedIn profile",
    "category": "Work",
    "priority": "Medium",
    "done": true,
    "dueInDays": -1,
    "notes": ""
  },
  {
    "title": "Record project demo video",
    "category": "Work",
    "priority": "High",
    "done": false,
    "dueInDays": 2,
    "notes": "Show all features"
  },
  {
    "title": "Prepare resume for internship",
    "category": "Work",
    "priority": "High",
    "done": true,
    "dueInDays": -4,
    "notes": "One page, ATS friendly"
  },
  {
    "title": "Apply for 3 internships",
    "category": "Work",
    "priority": "High",
    "done": false,
    "dueInDays": 3,
    "notes": ""
  },
  {
    "title": "Write README for expense tracker",
    "category": "Work",
    "priority": "Medium",
    "done": false,
    "dueInDays": 1,
    "notes": ""
  },
  {
    "title": "Test blog website on mobile",
    "category": "Work",
    "priority": "Medium",
    "done": true,
    "dueInDays": -2,
    "notes": ""
  },
  {
    "title": "Post project on LinkedIn",
    "category": "Work",
    "priority": "Medium",
    "done": false,
    "dueInDays": 5,
    "notes": "Add #codsoft"
  },
  {
    "title": "Pay mobile recharge",
    "category": "Personal",
    "priority": "Medium",
    "done": false,
    "dueInDays": -1,
    "notes": ""
  },
  {
    "title": "Call grandmother",
    "category": "Personal",
    "priority": "Low",
    "done": true,
    "dueInDays": -3,
    "notes": ""
  },
  {
    "title": "Clean study table",
    "category": "Personal",
    "priority": "Low",
    "done": false,
    "dueInDays": 5,
    "notes": ""
  },
  {
    "title": "Plan weekend trip",
    "category": "Personal",
    "priority": "Low",
    "done": false,
    "dueInDays": 8,
    "notes": ""
  },
  {
    "title": "Renew library card",
    "category": "Personal",
    "priority": "Low",
    "done": true,
    "dueInDays": -6,
    "notes": ""
  },
  {
    "title": "Reply to friend's message",
    "category": "Personal",
    "priority": "Low",
    "done": true,
    "dueInDays": 0,
    "notes": ""
  },
  {
    "title": "Morning walk for 30 minutes",
    "category": "Health",
    "priority": "Medium",
    "done": true,
    "dueInDays": 0,
    "notes": ""
  },
  {
    "title": "Drink 3 litres of water",
    "category": "Health",
    "priority": "Medium",
    "done": false,
    "dueInDays": 0,
    "notes": ""
  },
  {
    "title": "Sleep before 11 PM",
    "category": "Health",
    "priority": "Medium",
    "done": false,
    "dueInDays": 0,
    "notes": ""
  },
  {
    "title": "Yoga session",
    "category": "Health",
    "priority": "Low",
    "done": false,
    "dueInDays": 2,
    "notes": ""
  },
  {
    "title": "Buy notebooks and pens",
    "category": "Shopping",
    "priority": "Low",
    "done": false,
    "dueInDays": 3,
    "notes": ""
  },
  {
    "title": "Buy earphones",
    "category": "Shopping",
    "priority": "Medium",
    "done": false,
    "dueInDays": 9,
    "notes": "Budget Rs 800"
  },
  {
    "title": "Order a laptop bag",
    "category": "Shopping",
    "priority": "Low",
    "done": true,
    "dueInDays": -7,
    "notes": ""
  },
  {
    "title": "Grocery shopping",
    "category": "Shopping",
    "priority": "Medium",
    "done": false,
    "dueInDays": 1,
    "notes": "Milk, rice, fruits"
  }
];

const $ = id => document.getElementById(id);
const form = $("form"), list = $("list");

let tasks = load();
let editingId = null;
let filters = { q: "", status: "all", cat: "All categories", pri: "All priorities", sort: "due" };

/* ---------- Local Storage ---------- */
function load(){
  try { const d = JSON.parse(localStorage.getItem(KEY)); return Array.isArray(d) ? d : []; }
  catch { return []; }
}
function save(){ localStorage.setItem(KEY, JSON.stringify(tasks)); }

/* ---------- Helpers ---------- */
const newId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
const esc = s => String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function isoDate(d){
  const z = n => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}`;
}
const today = () => isoDate(new Date());
function inDays(n){ const d = new Date(); d.setDate(d.getDate() + n); return isoDate(d); }
const fmt = s => new Date(s + "T00:00:00").toLocaleDateString("en-IN", {day:"numeric", month:"short"});
const isLate = t => !t.done && t.due && t.due < today();

/* ---------- Dropdowns ---------- */
function fillSelects(){
  $("category").innerHTML = CATEGORIES.map(c => `<option>${c}</option>`).join("");
  $("fCat").innerHTML = ["All categories", ...CATEGORIES].map(c => `<option>${c}</option>`).join("");
}

/* ---------- Sorting ---------- */
const PRI = { High: 0, Medium: 1, Low: 2 };
function sorter(mode){
  const byDue = (a, b) => (a.due || "9999").localeCompare(b.due || "9999");
  return (a, b) => {
    if (a.done !== b.done) return a.done - b.done;           // pending tasks first
    if (mode === "priority") return (PRI[a.priority] - PRI[b.priority]) || byDue(a, b);
    if (mode === "newest") return b.id.localeCompare(a.id);
    if (mode === "az") return a.title.localeCompare(b.title);
    return byDue(a, b);
  };
}

/* ---------- Progress by category ---------- */
function drawBreakdown(){
  $("breakdown").innerHTML = tasks.length ? CATEGORIES.map(c => {
    const all = tasks.filter(t => t.category === c), d = all.filter(t => t.done).length;
    const pct = all.length ? Math.round(d / all.length * 100) : 0;
    return `<div class="brow"><span>${c}</span><div class="btrack"><div style="width:${pct}%"></div></div><span class="bnum">${d}/${all.length}</span></div>`;
  }).join("") : `<p class="empty">No data yet.</p>`;
}

/* ---------- Render ---------- */
function render(){
  const total = tasks.length;
  const done = tasks.filter(t => t.done).length;
  $("sTotal").textContent = total;
  $("sDone").textContent = done;
  $("sPend").textContent = total - done;
  $("sLate").textContent = tasks.filter(isLate).length;
  const pct = total ? Math.round(done / total * 100) : 0;
  $("bar").style.width = pct + "%";
  $("pct").textContent = total ? `${pct}% completed (${done} of ${total} tasks)` : "No tasks yet.";

  const q = filters.q.toLowerCase();
  const shown = tasks
    .filter(t => filters.status === "all" || (filters.status === "done") === t.done)
    .filter(t => filters.cat === "All categories" || t.category === filters.cat)
    .filter(t => filters.pri === "All priorities" || t.priority === filters.pri)
    .filter(t => !q || (t.title + " " + (t.notes || "")).toLowerCase().includes(q))
    .sort(sorter(filters.sort));
  $("count").textContent = total ? `Showing ${shown.length} of ${total} tasks` : "";
  drawBreakdown();

  if (!shown.length){
    list.innerHTML = `<li class="empty">${total ? "No tasks match your search or filters." : "Nothing here yet. Add a task or load sample tasks."}</li>`;
    return;
  }
  list.innerHTML = shown.map(t => {
    let dueChip = "";
    if (t.due){
      const cls = isLate(t) ? "late" : (!t.done && t.due === today() ? "today" : "");
      dueChip = `<span class="chip ${cls}">${isLate(t) ? "Overdue · " : (t.due === today() && !t.done ? "Due today · " : "Due ")}${fmt(t.due)}</span>`;
    }
    return `
    <li class="item ${t.priority} ${t.done ? "is-done" : ""}">
      <input type="checkbox" data-toggle="${t.id}" ${t.done ? "checked" : ""} aria-label="Mark complete">
      <div class="body">
        <div class="t">${esc(t.title)}</div>
        ${t.notes ? `<div class="note">${esc(t.notes)}</div>` : ""}
        <div class="chips">
          <span class="chip">${esc(t.category)}</span>
          <span class="chip">${esc(t.priority)} priority</span>
          ${dueChip}
        </div>
      </div>
      <div class="acts">
        <button data-edit="${t.id}">Edit</button>
        <button class="del" data-del="${t.id}">Delete</button>
      </div>
    </li>`;
  }).join("");
}

/* ---------- Add / update with validation ---------- */
form.addEventListener("submit", e => {
  e.preventDefault();
  const title = $("title").value.trim();
  const err = $("err");
  err.textContent = ""; $("title").classList.remove("bad");

  let msg = "";
  if (!title) msg = "Please enter a task.";
  else if (title.length < 3) msg = "Task must be at least 3 characters.";
  else if (tasks.some(t => t.id !== editingId && t.title.toLowerCase() === title.toLowerCase()))
    msg = "This task already exists.";
  if (msg){ err.textContent = msg; $("title").classList.add("bad"); $("title").focus(); return; }

  const data = { title, notes: $("notes").value.trim(), category: $("category").value, priority: $("priority").value, due: $("due").value };
  if (editingId) tasks = tasks.map(t => t.id === editingId ? {...t, ...data} : t);
  else tasks.push({ id: newId(), done: false, ...data });
  save(); resetForm(); render();
});
$("title").addEventListener("input", () => { $("err").textContent = ""; $("title").classList.remove("bad"); });

function resetForm(){
  editingId = null; form.reset();
  $("priority").value = "Medium";
  $("err").textContent = "";
  $("formTitle").textContent = "Add a task";
  $("saveBtn").textContent = "Add task";
  $("cancelBtn").hidden = true;
}
$("cancelBtn").addEventListener("click", resetForm);

/* ---------- Toggle / edit / delete (event delegation) ---------- */
list.addEventListener("click", e => {
  const ed = e.target.closest("[data-edit]"), del = e.target.closest("[data-del]");
  if (ed){
    const t = tasks.find(x => x.id === ed.dataset.edit); if (!t) return;
    editingId = t.id;
    $("title").value = t.title; $("notes").value = t.notes || ""; $("category").value = t.category;
    $("priority").value = t.priority; $("due").value = t.due || "";
    $("formTitle").textContent = "Edit task";
    $("saveBtn").textContent = "Save changes";
    $("cancelBtn").hidden = false;
    $("title").focus(); window.scrollTo({top: 0, behavior: "smooth"});
  } else if (del){
    if (!confirm("Delete this task?")) return;
    tasks = tasks.filter(t => t.id !== del.dataset.del);
    if (editingId === del.dataset.del) resetForm();
    save(); render();
  }
});
list.addEventListener("change", e => {
  const id = e.target.dataset.toggle; if (!id) return;
  tasks = tasks.map(t => t.id === id ? {...t, done: e.target.checked} : t);
  save(); render();
});

/* ---------- Search + filters ---------- */
$("search").addEventListener("input", e => { filters.q = e.target.value.trim(); render(); });
$("fCat").addEventListener("change", e => { filters.cat = e.target.value; render(); });
$("fPri").addEventListener("change", e => { filters.pri = e.target.value; render(); });
$("sort").addEventListener("change", e => { filters.sort = e.target.value; render(); });
$("tabs").addEventListener("click", e => {
  const b = e.target.closest(".tab"); if (!b) return;
  filters.status = b.dataset.s;
  document.querySelectorAll(".tab").forEach(x => x.classList.toggle("on", x === b));
  render();
});

/* ---------- Sample data / clear ---------- */
function loadData(rows){
  tasks = rows.map(s => ({ id: newId(), title: s.title, notes: s.notes || "", category: s.category, priority: s.priority, done: s.done, due: inDays(s.dueInDays) }));
  save(); render();
}
$("sampleBtn").addEventListener("click", () => loadData(SAMPLE));
$("largeBtn").addEventListener("click", () => loadData(LARGE));
$("clearDone").addEventListener("click", () => {
  if (!tasks.some(t => t.done) || !confirm("Remove all completed tasks?")) return;
  tasks = tasks.filter(t => !t.done); save(); render();
});
$("clearAll").addEventListener("click", () => {
  if (!tasks.length || !confirm("Delete all tasks?")) return;
  tasks = []; save(); resetForm(); render();
});

/* ---------- Dark mode ---------- */
function setTheme(t){
  document.documentElement.setAttribute("data-theme", t);
  try { localStorage.setItem(THEME_KEY, t); } catch {}
  $("theme").textContent = t === "dark" ? "☀" : "🌙";
}
$("theme").addEventListener("click", () =>
  setTheme(document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark"));
let savedTheme = "light"; try { savedTheme = localStorage.getItem(THEME_KEY) || "light"; } catch {}
setTheme(savedTheme);

/* ---------- Start ---------- */
$("today").textContent = new Date().toLocaleDateString("en-IN", {weekday:"long", day:"numeric", month:"long", year:"numeric"});
fillSelects(); render();

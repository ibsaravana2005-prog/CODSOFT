# Personal Portfolio Website (Task 1)

Built with HTML, CSS and JavaScript. No installation needed.

## Run
1. Extract the zip.
2. Double-click index.html (Chrome / Edge), or use Live Server in VS Code.

## Folder
- index.html, style.css, script.js
- images/  profile photo + project screenshots
- assets/  Saravana_Kumar_M_Resume.pdf (Download CV button)
- projects/  working copies of Expense Tracker, To-Do List (Live demo links)

## Change these before submitting
- script.js: GH / project "code" links -> your real GitHub repo links
- index.html: update the LinkedIn link if your profile URL is different
- Replace images/profile.jpg or assets/ resume PDF to update them

## Requirements covered
Responsive layout, sections (Home, About, Skills, Projects, Resume, Contact), project cards with
image + description + links, smooth scrolling + hover animations + filter tabs + typing effect,
mobile hamburger menu, Download CV button, contact form validation, works on all screen sizes.

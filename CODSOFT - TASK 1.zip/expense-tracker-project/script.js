/* Expense Tracker - script.js
   Data is saved in the browser's Local Storage under this key. */
const KEY = "expense-tracker-data";
const EXPENSE_CATS = ["Food","Transport","Shopping","Bills","Health","Entertainment","Education","Other"];
const INCOME_CATS  = ["Salary","Pocket money","Freelance","Gift","Other"];

let transactions = load();
let editingId = null;

const $ = id => document.getElementById(id);
const form = $("form"), list = $("list"), catSel = $("category"), filterSel = $("filter");

/* ---------- Sample dataset (same as data/sample-data.json) ---------- */
const SAMPLE_DATA = [
  {
    "type": "income",
    "title": "Monthly pocket money",
    "amount": 5000,
    "category": "Pocket money",
    "date": "2026-10-01"
  },
  {
    "type": "expense",
    "title": "College canteen lunch",
    "amount": 120,
    "category": "Food",
    "date": "2026-10-02"
  },
  {
    "type": "expense",
    "title": "Bus pass",
    "amount": 450,
    "category": "Transport",
    "date": "2026-10-03"
  },
  {
    "type": "expense",
    "title": "Mobile recharge",
    "amount": 299,
    "category": "Bills",
    "date": "2026-10-04"
  },
  {
    "type": "income",
    "title": "Freelance web page",
    "amount": 8000,
    "category": "Freelance",
    "date": "2026-10-05"
  },
  {
    "type": "expense",
    "title": "Notebooks and pens",
    "amount": 260,
    "category": "Education",
    "date": "2026-10-06"
  },
  {
    "type": "expense",
    "title": "Movie with friends",
    "amount": 350,
    "category": "Entertainment",
    "date": "2026-10-08"
  },
  {
    "type": "income",
    "title": "Part-time salary",
    "amount": 12000,
    "category": "Salary",
    "date": "2026-10-10"
  },
  {
    "type": "expense",
    "title": "T-shirt",
    "amount": 799,
    "category": "Shopping",
    "date": "2026-10-12"
  },
  {
    "type": "expense",
    "title": "Pharmacy",
    "amount": 180,
    "category": "Health",
    "date": "2026-10-15"
  },
  {
    "type": "expense",
    "title": "Electricity share",
    "amount": 600,
    "category": "Bills",
    "date": "2026-10-18"
  },
  {
    "type": "expense",
    "title": "Dinner",
    "amount": 420,
    "category": "Food",
    "date": "2026-10-20"
  },
  {
    "type": "expense",
    "title": "Auto fare",
    "amount": 90,
    "category": "Transport",
    "date": "2026-10-22"
  }
];

/* ---------- Large dataset (same as data/large-dataset.json) ---------- */
const LARGE_DATA = [{"type":"income","title":"Monthly pocket money","amount":5000,"category":"Pocket money","date":"2026-07-01"},
  {"type":"expense","title":"Project printing","amount":260,"category":"Education","date":"2026-07-01"},
  {"type":"expense","title":"Game recharge","amount":350,"category":"Entertainment","date":"2026-07-02"},
  {"type":"expense","title":"OTT subscription","amount":240,"category":"Entertainment","date":"2026-07-04"},
  {"type":"expense","title":"Groceries","amount":450,"category":"Food","date":"2026-07-04"},
  {"type":"expense","title":"Doctor consultation","amount":380,"category":"Health","date":"2026-07-06"},
  {"type":"income","title":"Part-time salary","amount":11000,"category":"Salary","date":"2026-07-10"},
  {"type":"expense","title":"Biryani","amount":260,"category":"Food","date":"2026-07-11"},
  {"type":"expense","title":"Bus pass","amount":440,"category":"Transport","date":"2026-07-12"},
  {"type":"expense","title":"Pharmacy","amount":300,"category":"Health","date":"2026-07-13"},
  {"type":"expense","title":"Notebooks and pens","amount":220,"category":"Education","date":"2026-07-14"},
  {"type":"expense","title":"College canteen lunch","amount":120,"category":"Food","date":"2026-07-15"},
  {"type":"expense","title":"Bus pass","amount":400,"category":"Transport","date":"2026-07-17"},
  {"type":"expense","title":"Tea and snacks","amount":51,"category":"Food","date":"2026-07-17"},
  {"type":"expense","title":"Notebooks and pens","amount":330,"category":"Education","date":"2026-07-18"},
  {"type":"expense","title":"College canteen lunch","amount":100,"category":"Food","date":"2026-07-19"},
  {"type":"expense","title":"Internet share","amount":320,"category":"Bills","date":"2026-07-20"},
  {"type":"expense","title":"Groceries","amount":890,"category":"Food","date":"2026-07-20"},
  {"type":"expense","title":"T-shirt","amount":420,"category":"Shopping","date":"2026-07-21"},
  {"type":"expense","title":"College canteen lunch","amount":120,"category":"Food","date":"2026-07-21"},
  {"type":"income","title":"Freelance web project","amount":6000,"category":"Freelance","date":"2026-07-22"},
  {"type":"expense","title":"College canteen lunch","amount":100,"category":"Food","date":"2026-07-22"},
  {"type":"expense","title":"Bus pass","amount":440,"category":"Transport","date":"2026-07-23"},
  {"type":"expense","title":"Doctor consultation","amount":270,"category":"Health","date":"2026-07-25"},
  {"type":"expense","title":"Game recharge","amount":400,"category":"Entertainment","date":"2026-07-28"},
  {"type":"expense","title":"College canteen lunch","amount":70,"category":"Food","date":"2026-07-31"},
  {"type":"income","title":"Monthly pocket money","amount":5000,"category":"Pocket money","date":"2026-08-01"},
  {"type":"expense","title":"Bus pass","amount":470,"category":"Transport","date":"2026-08-02"},
  {"type":"expense","title":"Biryani","amount":240,"category":"Food","date":"2026-08-02"},
  {"type":"expense","title":"T-shirt","amount":580,"category":"Shopping","date":"2026-08-03"},
  {"type":"expense","title":"Exam fee","amount":350,"category":"Education","date":"2026-08-04"},
  {"type":"expense","title":"Movie with friends","amount":210,"category":"Entertainment","date":"2026-08-07"},
  {"type":"expense","title":"College canteen lunch","amount":120,"category":"Food","date":"2026-08-07"},
  {"type":"expense","title":"Dinner","amount":220,"category":"Food","date":"2026-08-07"},
  {"type":"expense","title":"Online course","amount":930,"category":"Education","date":"2026-08-07"},
  {"type":"expense","title":"Exam fee","amount":330,"category":"Education","date":"2026-08-07"},
  {"type":"expense","title":"Bus pass","amount":420,"category":"Transport","date":"2026-08-07"},
  {"type":"expense","title":"Dinner","amount":280,"category":"Food","date":"2026-08-09"},
  {"type":"expense","title":"Biryani","amount":220,"category":"Food","date":"2026-08-09"},
  {"type":"expense","title":"Petrol","amount":390,"category":"Transport","date":"2026-08-09"},
  {"type":"income","title":"Part-time salary","amount":12500,"category":"Salary","date":"2026-08-10"},
  {"type":"expense","title":"Backpack","amount":1040,"category":"Shopping","date":"2026-08-10"},
  {"type":"expense","title":"Project printing","amount":220,"category":"Education","date":"2026-08-11"},
  {"type":"expense","title":"Auto fare","amount":70,"category":"Transport","date":"2026-08-12"},
  {"type":"expense","title":"College canteen lunch","amount":70,"category":"Food","date":"2026-08-13"},
  {"type":"expense","title":"Donation","amount":150,"category":"Other","date":"2026-08-14"},
  {"type":"expense","title":"Mobile recharge","amount":240,"category":"Bills","date":"2026-08-14"},
  {"type":"expense","title":"OTT subscription","amount":290,"category":"Entertainment","date":"2026-08-15"},
  {"type":"income","title":"Freelance web project","amount":3000,"category":"Freelance","date":"2026-08-17"},
  {"type":"expense","title":"Tea and snacks","amount":33,"category":"Food","date":"2026-08-17"},
  {"type":"income","title":"Birthday gift","amount":2000,"category":"Gift","date":"2026-08-19"},
  {"type":"expense","title":"Notebooks and pens","amount":330,"category":"Education","date":"2026-08-19"},
  {"type":"expense","title":"Petrol","amount":310,"category":"Transport","date":"2026-08-19"},
  {"type":"expense","title":"College canteen lunch","amount":140,"category":"Food","date":"2026-08-19"},
  {"type":"expense","title":"Exam fee","amount":730,"category":"Education","date":"2026-08-20"},
  {"type":"expense","title":"Dinner","amount":170,"category":"Food","date":"2026-08-21"},
  {"type":"expense","title":"Auto fare","amount":190,"category":"Transport","date":"2026-08-22"},
  {"type":"expense","title":"Petrol","amount":460,"category":"Transport","date":"2026-08-23"},
  {"type":"expense","title":"Haircut","amount":90,"category":"Other","date":"2026-08-23"},
  {"type":"expense","title":"Bus fare","amount":39,"category":"Transport","date":"2026-08-24"},
  {"type":"expense","title":"Earphones","amount":720,"category":"Shopping","date":"2026-08-24"},
  {"type":"expense","title":"Groceries","amount":380,"category":"Food","date":"2026-08-26"},
  {"type":"expense","title":"Groceries","amount":580,"category":"Food","date":"2026-08-26"},
  {"type":"expense","title":"Online course","amount":1270,"category":"Education","date":"2026-08-27"},
  {"type":"expense","title":"Notebooks and pens","amount":120,"category":"Education","date":"2026-08-27"},
  {"type":"expense","title":"T-shirt","amount":710,"category":"Shopping","date":"2026-08-27"},
  {"type":"expense","title":"Groceries","amount":620,"category":"Food","date":"2026-08-28"},
  {"type":"expense","title":"T-shirt","amount":680,"category":"Shopping","date":"2026-08-28"},
  {"type":"expense","title":"Petrol","amount":500,"category":"Transport","date":"2026-08-29"},
  {"type":"expense","title":"Petrol","amount":350,"category":"Transport","date":"2026-08-29"},
  {"type":"expense","title":"Groceries","amount":790,"category":"Food","date":"2026-08-29"},
  {"type":"expense","title":"Dinner","amount":410,"category":"Food","date":"2026-08-30"},
  {"type":"expense","title":"Notebooks and pens","amount":260,"category":"Education","date":"2026-08-30"},
  {"type":"income","title":"Monthly pocket money","amount":5000,"category":"Pocket money","date":"2026-09-01"},
  {"type":"expense","title":"Exam fee","amount":720,"category":"Education","date":"2026-09-01"},
  {"type":"expense","title":"Game recharge","amount":350,"category":"Entertainment","date":"2026-09-03"},
  {"type":"expense","title":"Groceries","amount":360,"category":"Food","date":"2026-09-03"},
  {"type":"expense","title":"Electricity share","amount":550,"category":"Bills","date":"2026-09-03"},
  {"type":"expense","title":"Doctor consultation","amount":420,"category":"Health","date":"2026-09-04"},
  {"type":"expense","title":"Bus pass","amount":460,"category":"Transport","date":"2026-09-04"},
  {"type":"expense","title":"Game recharge","amount":210,"category":"Entertainment","date":"2026-09-05"},
  {"type":"expense","title":"Notebooks and pens","amount":300,"category":"Education","date":"2026-09-05"},
  {"type":"expense","title":"Gift for friend","amount":530,"category":"Other","date":"2026-09-07"},
  {"type":"expense","title":"Groceries","amount":550,"category":"Food","date":"2026-09-07"},
  {"type":"expense","title":"Bus pass","amount":440,"category":"Transport","date":"2026-09-08"},
  {"type":"expense","title":"Mobile recharge","amount":280,"category":"Bills","date":"2026-09-08"},
  {"type":"expense","title":"Bus fare","amount":42,"category":"Transport","date":"2026-09-09"},
  {"type":"expense","title":"College canteen lunch","amount":140,"category":"Food","date":"2026-09-09"},
  {"type":"income","title":"Part-time salary","amount":12500,"category":"Salary","date":"2026-09-10"},
  {"type":"expense","title":"Mobile recharge","amount":290,"category":"Bills","date":"2026-09-10"},
  {"type":"expense","title":"Bus pass","amount":500,"category":"Transport","date":"2026-09-10"},
  {"type":"expense","title":"Internet share","amount":280,"category":"Bills","date":"2026-09-11"},
  {"type":"expense","title":"Groceries","amount":440,"category":"Food","date":"2026-09-11"},
  {"type":"expense","title":"Shoes","amount":1220,"category":"Shopping","date":"2026-09-12"},
  {"type":"expense","title":"Groceries","amount":820,"category":"Food","date":"2026-09-14"},
  {"type":"expense","title":"Petrol","amount":370,"category":"Transport","date":"2026-09-14"},
  {"type":"expense","title":"Auto fare","amount":180,"category":"Transport","date":"2026-09-18"},
  {"type":"expense","title":"Internet share","amount":390,"category":"Bills","date":"2026-09-18"},
  {"type":"expense","title":"Bus pass","amount":410,"category":"Transport","date":"2026-09-20"},
  {"type":"expense","title":"Petrol","amount":500,"category":"Transport","date":"2026-09-20"},
  {"type":"expense","title":"Tea and snacks","amount":43,"category":"Food","date":"2026-09-20"},
  {"type":"expense","title":"Bus fare","amount":43,"category":"Transport","date":"2026-09-21"},
  {"type":"expense","title":"Auto fare","amount":100,"category":"Transport","date":"2026-09-21"},
  {"type":"expense","title":"Petrol","amount":380,"category":"Transport","date":"2026-09-21"},
  {"type":"income","title":"Freelance web project","amount":8000,"category":"Freelance","date":"2026-09-23"},
  {"type":"expense","title":"OTT subscription","amount":220,"category":"Entertainment","date":"2026-09-23"},
  {"type":"expense","title":"Internet share","amount":380,"category":"Bills","date":"2026-09-23"},
  {"type":"expense","title":"Game recharge","amount":220,"category":"Entertainment","date":"2026-09-23"},
  {"type":"expense","title":"Groceries","amount":410,"category":"Food","date":"2026-09-23"},
  {"type":"expense","title":"Pharmacy","amount":230,"category":"Health","date":"2026-09-23"},
  {"type":"expense","title":"Notebooks and pens","amount":340,"category":"Education","date":"2026-09-24"},
  {"type":"expense","title":"Biryani","amount":240,"category":"Food","date":"2026-09-25"},
  {"type":"expense","title":"Exam fee","amount":740,"category":"Education","date":"2026-09-25"},
  {"type":"expense","title":"Auto fare","amount":90,"category":"Transport","date":"2026-09-26"},
  {"type":"expense","title":"Bus pass","amount":440,"category":"Transport","date":"2026-09-26"},
  {"type":"expense","title":"Internet share","amount":270,"category":"Bills","date":"2026-09-27"},
  {"type":"expense","title":"College canteen lunch","amount":100,"category":"Food","date":"2026-09-27"},
  {"type":"expense","title":"Petrol","amount":480,"category":"Transport","date":"2026-09-28"},
  {"type":"expense","title":"Mobile recharge","amount":250,"category":"Bills","date":"2026-09-30"},
  {"type":"income","title":"Monthly pocket money","amount":5000,"category":"Pocket money","date":"2026-10-01"},
  {"type":"expense","title":"Online course","amount":1370,"category":"Education","date":"2026-10-01"},
  {"type":"expense","title":"Game recharge","amount":150,"category":"Entertainment","date":"2026-10-01"},
  {"type":"expense","title":"Mobile recharge","amount":260,"category":"Bills","date":"2026-10-03"},
  {"type":"expense","title":"College canteen lunch","amount":130,"category":"Food","date":"2026-10-03"},
  {"type":"expense","title":"Bus fare","amount":36,"category":"Transport","date":"2026-10-04"},
  {"type":"expense","title":"College canteen lunch","amount":150,"category":"Food","date":"2026-10-07"},
  {"type":"expense","title":"Project printing","amount":280,"category":"Education","date":"2026-10-07"},
  {"type":"expense","title":"Bus fare","amount":49,"category":"Transport","date":"2026-10-07"},
  {"type":"expense","title":"Bus fare","amount":40,"category":"Transport","date":"2026-10-08"},
  {"type":"expense","title":"Groceries","amount":330,"category":"Food","date":"2026-10-08"},
  {"type":"expense","title":"Doctor consultation","amount":460,"category":"Health","date":"2026-10-09"},
  {"type":"income","title":"Part-time salary","amount":12500,"category":"Salary","date":"2026-10-10"},
  {"type":"expense","title":"College canteen lunch","amount":140,"category":"Food","date":"2026-10-10"},
  {"type":"expense","title":"Tea and snacks","amount":41,"category":"Food","date":"2026-10-10"},
  {"type":"expense","title":"Internet share","amount":320,"category":"Bills","date":"2026-10-11"},
  {"type":"expense","title":"Petrol","amount":380,"category":"Transport","date":"2026-10-11"},
  {"type":"expense","title":"Project printing","amount":150,"category":"Education","date":"2026-10-12"},
  {"type":"expense","title":"College canteen lunch","amount":70,"category":"Food","date":"2026-10-12"},
  {"type":"expense","title":"Pharmacy","amount":340,"category":"Health","date":"2026-10-12"},
  {"type":"expense","title":"Dinner","amount":270,"category":"Food","date":"2026-10-13"},
  {"type":"expense","title":"Petrol","amount":220,"category":"Transport","date":"2026-10-15"},
  {"type":"expense","title":"Mobile recharge","amount":280,"category":"Bills","date":"2026-10-16"},
  {"type":"income","title":"Festival gift money","amount":1500,"category":"Gift","date":"2026-10-18"},
  {"type":"expense","title":"Biryani","amount":270,"category":"Food","date":"2026-10-19"},
  {"type":"expense","title":"Tea and snacks","amount":49,"category":"Food","date":"2026-10-19"},
  {"type":"expense","title":"Pharmacy","amount":330,"category":"Health","date":"2026-10-20"},
  {"type":"expense","title":"College canteen lunch","amount":140,"category":"Food","date":"2026-10-22"},
  {"type":"income","title":"Freelance web project","amount":8000,"category":"Freelance","date":"2026-10-23"},
  {"type":"expense","title":"Biryani","amount":300,"category":"Food","date":"2026-10-26"}];

/* ---------- Local Storage ---------- */
function load(){
  try { return JSON.parse(localStorage.getItem(KEY)) || []; }
  catch { return []; }
}
function save(){ localStorage.setItem(KEY, JSON.stringify(transactions)); }

/* ---------- Helpers ---------- */
const money = n => "₹" + Number(n).toLocaleString("en-IN", {maximumFractionDigits:2});
const typeVal = () => form.querySelector("input[name=type]:checked").value;
const newId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
function esc(s){
  return s.replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
}

/* ---------- Dropdowns ---------- */
function fillCategories(){
  const cats = typeVal() === "income" ? INCOME_CATS : EXPENSE_CATS;
  catSel.innerHTML = cats.map(c => `<option>${c}</option>`).join("");
}
function fillFilter(){
  const all = [...new Set([...EXPENSE_CATS, ...INCOME_CATS])];
  filterSel.innerHTML = ["All", ...all].map(c => `<option>${c}</option>`).join("");
}

/* ---------- Render: summary cards + history table ---------- */
function render(){
  const inc = transactions.filter(t => t.type === "income").reduce((s,t) => s + t.amount, 0);
  const exp = transactions.filter(t => t.type === "expense").reduce((s,t) => s + t.amount, 0);
  $("inc").textContent = money(inc);
  $("exp").textContent = money(exp);
  $("bal").textContent = money(inc - exp);

  const f = filterSel.value;
  const shown = transactions
    .filter(t => f === "All" || t.category === f)
    .sort((a,b) => b.date.localeCompare(a.date));

  if (!shown.length){
    list.innerHTML = `<tr><td colspan="5" class="empty">No transactions to show. Add one, or load sample data.</td></tr>`;
    return;
  }
  list.innerHTML = shown.map(t => `
    <tr>
      <td>${t.date}</td>
      <td>${esc(t.title)}</td>
      <td>${esc(t.category)}</td>
      <td class="amt ${t.type}">${t.type === "income" ? "+" : "−"}${money(t.amount)}</td>
      <td class="row-actions">
        <button class="edit" onclick="startEdit('${t.id}')">Edit</button>
        <button class="del" onclick="removeTx('${t.id}')">Delete</button>
      </td>
    </tr>`).join("");
}

/* ---------- Add / update ---------- */
form.addEventListener("submit", e => {
  e.preventDefault();
  const data = {
    type: typeVal(),
    title: $("title").value.trim(),
    amount: parseFloat($("amount").value),
    category: catSel.value,
    date: $("date").value
  };
  if (!data.title || !(data.amount > 0)) return;

  if (editingId){
    transactions = transactions.map(t => t.id === editingId ? {...t, ...data} : t);
  } else {
    transactions.push({ id: newId(), ...data });
  }
  save(); resetForm(); render();
});
form.querySelectorAll("input[name=type]").forEach(r => r.addEventListener("change", fillCategories));

/* ---------- Edit / delete ---------- */
function startEdit(id){
  const t = transactions.find(x => x.id === id);
  if (!t) return;
  editingId = id;
  form.querySelector(`input[name=type][value=${t.type}]`).checked = true;
  fillCategories();
  $("title").value = t.title;
  $("amount").value = t.amount;
  catSel.value = t.category;
  $("date").value = t.date;
  $("formTitle").textContent = "Edit transaction";
  $("saveBtn").textContent = "Save changes";
  $("cancelBtn").hidden = false;
  window.scrollTo({top:0, behavior:"smooth"});
}
function removeTx(id){
  if (!confirm("Delete this transaction?")) return;
  transactions = transactions.filter(t => t.id !== id);
  save(); render();
}
function resetForm(){
  editingId = null;
  form.reset();
  fillCategories();
  $("date").value = new Date().toISOString().slice(0,10);
  $("formTitle").textContent = "Add transaction";
  $("saveBtn").textContent = "Add transaction";
  $("cancelBtn").hidden = true;
}
$("cancelBtn").addEventListener("click", resetForm);
filterSel.addEventListener("change", render);

/* ---------- Sample data / clear ---------- */
$("sampleBtn").addEventListener("click", () => {
  transactions = SAMPLE_DATA.map(r => ({ id: newId(), ...r }));
  save(); render();
});
$("largeBtn").addEventListener("click", () => {
  transactions = LARGE_DATA.map(r => ({ id: newId(), ...r }));
  save(); render();
});
$("clearBtn").addEventListener("click", () => {
  if (!transactions.length || !confirm("Delete all transactions?")) return;
  transactions = []; save(); render();
});

/* ---------- Start ---------- */
fillFilter(); resetForm(); render();

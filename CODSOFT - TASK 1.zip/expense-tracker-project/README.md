# Expense Tracker (Task 3)

A personal expense tracker built with HTML, CSS and JavaScript. No installation needed.

## Folder structure
```
expense-tracker-project/
├── index.html            page structure
├── style.css             styling (responsive)
├── script.js             app logic + Local Storage
├── data/
│   ├── sample-data.js    13-record dataset (js copy)
│   ├── sample-data.json  13-record dataset
│   ├── sample-data.csv   13-record dataset for Excel
│   ├── large-dataset.json  149 records (Jul-Oct 2026)
│   ├── large-dataset.csv   same, for Excel
│   ├── sample-data.json  same data in JSON
│   └── sample-data.csv   same data for Excel
└── README.md
```

## How to run
1. Extract the zip and open the folder.
2. Double-click `index.html` (opens in Chrome/Edge).
   Or in VS Code: File > Open Folder > right-click `index.html` > Open with Live Server.
3. Click **Load sample data** to fill the app.

## Expected output with sample data
- Total income: Rs 25,000
- Total expenses: Rs 3,568
- Current balance: Rs 21,432
- 13 transactions, newest first. Filter "Food" shows 2 rows (Rs 120 and Rs 420).

## Requirements covered
Responsive UI, add income/expense, history with date and category, auto totals,
Local Storage, edit and delete, category filter, summary cards.

## Large dataset (149 records)
Click **Load large dataset**. Expected output:
- Total income: Rs 97,000
- Total expenses: Rs 45,936
- Current balance: Rs 51,064
- Filter "Food" shows 43 rows.

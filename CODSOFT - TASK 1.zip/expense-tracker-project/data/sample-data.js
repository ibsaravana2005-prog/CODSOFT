// Same data as sample-data.json (as .js so it works when opening index.html directly)
const SAMPLE_DATA = [
  {
    "type": "income",
    "title": "Monthly pocket money",
    "amount": 5000,
    "category": "Pocket money",
    "date": "2026-10-01"
  },
  {
    "type": "expense",
    "title": "College canteen lunch",
    "amount": 120,
    "category": "Food",
    "date": "2026-10-02"
  },
  {
    "type": "expense",
    "title": "Bus pass",
    "amount": 450,
    "category": "Transport",
    "date": "2026-10-03"
  },
  {
    "type": "expense",
    "title": "Mobile recharge",
    "amount": 299,
    "category": "Bills",
    "date": "2026-10-04"
  },
  {
    "type": "income",
    "title": "Freelance web page",
    "amount": 8000,
    "category": "Freelance",
    "date": "2026-10-05"
  },
  {
    "type": "expense",
    "title": "Notebooks and pens",
    "amount": 260,
    "category": "Education",
    "date": "2026-10-06"
  },
  {
    "type": "expense",
    "title": "Movie with friends",
    "amount": 350,
    "category": "Entertainment",
    "date": "2026-10-08"
  },
  {
    "type": "income",
    "title": "Part-time salary",
    "amount": 12000,
    "category": "Salary",
    "date": "2026-10-10"
  },
  {
    "type": "expense",
    "title": "T-shirt",
    "amount": 799,
    "category": "Shopping",
    "date": "2026-10-12"
  },
  {
    "type": "expense",
    "title": "Pharmacy",
    "amount": 180,
    "category": "Health",
    "date": "2026-10-15"
  },
  {
    "type": "expense",
    "title": "Electricity share",
    "amount": 600,
    "category": "Bills",
    "date": "2026-10-18"
  },
  {
    "type": "expense",
    "title": "Dinner",
    "amount": 420,
    "category": "Food",
    "date": "2026-10-20"
  },
  {
    "type": "expense",
    "title": "Auto fare",
    "amount": 90,
    "category": "Transport",
    "date": "2026-10-22"
  }
];
